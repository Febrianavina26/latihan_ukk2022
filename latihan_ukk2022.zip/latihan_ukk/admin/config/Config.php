<?php

define('baseurl','http://localhost/Latihan_ukk/public');