<?php
class Portofolio extends Controller
{
  public function index()
    {
  
      $data['profile'] = $this->model('portofolioModel')->getProfile();
      $data['about'] = $this->model('portofolioModel')->getAbout();
      $data['project'] = $this->model('portofolioModel')->getProject();

      $this->view('portofolio/index', $data);
    }
  public function pesan()
    {
      if ( $this->model('portofolioModel')->tampungPesan($_POST) > 0) {
        echo "
        <script>
        alert('DATA berhasil dikirim')
        window.location.href='http://localhost/latihan_ukk/public/'
        </script>
        ";
      } else {
          echo "
          alert('gagal dikirim')
           window.location.href='http://localhost/latihan_ukk/public/'
           <?script>
          ";
     }
    }
  }
     

  

    

  