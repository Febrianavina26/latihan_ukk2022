<?php

define('baseurl','http://localhost/latihan_ukk/public');