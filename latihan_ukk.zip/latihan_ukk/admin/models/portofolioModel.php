<?php

class portofolioModel{


    public function _construct()
    {

    }


}
