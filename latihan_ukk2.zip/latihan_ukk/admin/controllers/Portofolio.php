<?php

class Portofolio extends Controller
{
  public function index()
    {

    $data['profile'] = $this->model('portofolioModel');
    
    $this->view('portofolio/index',$data);
    }
  public function index()
    {

    $data['profile'] = $this->model('portofolioModel')->getProfile();

    $data['about'] = $this->model('portofolioModel')->getAbout();

    $this->view('portofolio/index',$data);
    }  
  public function getProject()
    {
    $this->stmt = $this->$dbh->prepare('SELECT * FROM project');
    $this->stmt->execute();
    return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }  
  public function index()
     {

    $data['profile'] = $this->model('portofolioModel')->getProfile();

    $data['about'] = $this->model('portofolioModel')->getAbout();

    $data['project'] = $this->model('portofolioModel')->getProject();

    $this->view('portofolio/index',$data);
    }
}  